package com.example.backend.Entity;

public enum Role {
    EMPLOYEE,
    MANAGER,
    ADMIN
}
