package com.example.backend.Service;

public class RoleServiceImpl implements RoleService {

}
